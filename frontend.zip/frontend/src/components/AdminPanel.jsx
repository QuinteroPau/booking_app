import { useEffect, useState } from 'react'
import supabase from '../supabaseClient'
import AgendaCalendar from './AgendaCalendar'
import '../styles/main.css'
import DatePickerModal from './DatePickerModal'

const AdminPanel = () => {
  const [date, setDate] = useState(new Date())
  const [reservas, setReservas] = useState([])
  const [loading, setLoading] = useState(false)
  const [diasConReservas, setDiasConReservas] = useState([])
  const [mostrarDatePicker, setMostrarDatePicker] = useState(false)
  const [mostrarEditorVisual, setMostrarEditorVisual] = useState(false)
  const [mostrarEditorRestaurante, setMostrarEditorRestaurante] = useState(false)
  const [reservaEditando, setReservaEditando] = useState(null);
  const [visual, setVisual] = useState({
    nombre: '',
    color_primario: '',
    color_secundario: '',
    fondo_url: '',
    logo_url: '',
    turnos: [] // aquí guardaremos los turnos
  })


  const formatDateLocal = (date) => {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}
const handleEditarReserva = (reserva) => {
  setReservaEditando(reserva);
}

const formattedDate = formatDateLocal(date)
  const hoverPrimario = darkenColor(visual.color_primario, 20)
  const hoverSecundario = darkenColor(visual.color_secundario, 20)
  useEffect(() => {
  const fetchConfiguracionVisual = async () => {
    //const slug = window.location.hostname.split('.')[0] === 'localhost' ? 'ejemplo' : window.location.hostname.split('.')[0]
    let slug = 'ejemplo'
    const { data, error } = await supabase
      .from('restaurantes')
      .select('nombre, color_primario, color_primario_hover, color_secundario, color_secundario_hover, fondo_url, logo_url, turnos, direccion')
      .eq('slug', slug)
      .single()


    if (error) {
      console.error('Error al obtener la configuración visual:', error)
    } else {
      setVisual(data)
    }
  }

  fetchConfiguracionVisual()
}, [])
  useEffect(() => {
    const fetchReservas = async () => {
      setLoading(true)
      const { data, error } = await supabase
        .from('reservas')
        .select('*')
        .eq('date', formattedDate)
        .order('time', { ascending: true })

      if (error) console.error('Error al obtener reservas:', error)
      else setReservas(data)

      setLoading(false)
    }

    fetchReservas()
  }, [formattedDate])

  useEffect(() => {
    const fetchDiasConReservas = async () => {
      const today = new Date()
      const futureDate = new Date()
      futureDate.setDate(today.getDate() + 100)

      const { data, error } = await supabase
        .from('reservas')
        .select('date')
        .gte('date', today.toISOString().split('T')[0])
        .lte('date', futureDate.toISOString().split('T')[0])

      if (!error && data) {
        const fechas = [...new Set(data.map(r => r.date))]
        setDiasConReservas(fechas)
      }
    }

    fetchDiasConReservas()
  }, [])

  const updateVisual = (campo, valor) => {
  setVisual((prev) => {
    const updated = { ...prev, [campo]: valor }

    if (campo === 'color_primario') {
      updated.color_primario_hover = darkenColor(valor, 15)
    }

    if (campo === 'color_secundario') {
      updated.color_secundario_hover = darkenColor(valor, 15)
    }

    return updated
  })
}

  const handleVisualSubmit = async (e) => {
  e.preventDefault()

  //const slug = window.location.hostname.split('.')[0] === 'localhost' ? 'ejemplo' : window.location.hostname.split('.')[0]

  let slug = 'ejemplo'
  const { error } = await supabase
    .from('restaurantes')
    .update(visual)
    .eq('slug', slug)

  if (error) {
    alert('Error al guardar los cambios.')
    console.error(error)
  } else {
    alert('Cambios guardados con éxito.')
    setMostrarEditorVisual(false)
    location.reload()
  }
}
const handleRestauranteSubmit = async (e) => {
  e.preventDefault()

  let slug = 'ejemplo'
  const { error } = await supabase
    .from('restaurantes')
    .update({
      nombre: visual.nombre,
      turnos: visual.turnos
    })
    .eq('slug', slug)

  if (error) {
    alert('Error al guardar los cambios.')
    console.error(error)
  } else {
    alert('Cambios guardados con éxito.')
    setMostrarEditorRestaurante(false)
    location.reload()
  }
}
const handleGuardarReserva = async (e) => {
  e.preventDefault();

  const { error } = await supabase
    .from('reservas')
    .update({
      date: reservaEditando.date,
      name: reservaEditando.name,
      email: reservaEditando.email,
      phone: reservaEditando.phone,
      guests: reservaEditando.guests,
      turno: reservaEditando.turno,
      time: reservaEditando.time,
      special_requests: reservaEditando.specialRequests
    })
    .eq('id', reservaEditando.id);

  if (error) {
    alert('Error al guardar los cambios');
    console.error(error);
  } else {
    alert('Reserva actualizada');
    setReservaEditando(null);

    // ✅ 1. Recargar reservas del día
    const { data, error: fetchError } = await supabase
      .from('reservas')
      .select('*')
      .eq('date', formattedDate)
      .order('time', { ascending: true });

    if (!fetchError) {
      setReservas(data);
    }

    // ✅ 2. Recargar los días con reservas actualizados
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + 100);

    const { data: diasData, error: diasError } = await supabase
      .from('reservas')
      .select('date')
      .gte('date', today.toISOString().split('T')[0])
      .lte('date', futureDate.toISOString().split('T')[0]);

    if (!diasError && diasData) {
      const fechasActualizadas = [...new Set(diasData.map(r => r.date))];
      setDiasConReservas(fechasActualizadas);
    }
  }
};




  const handleImageUpload = async (e) => {
  const file = e.target.files[0]
  if (!file) return

    //const slug = window.location.hostname.split('.')[0] === 'localhost' ? 'ejemplo' : window.location.hostname.split('.')[0]
    
    let slug = 'ejemplo'
    const fileName = `${slug}/${Date.now()}_${file.name}`

    const { error: uploadError } = await supabase
      .storage
      .from('fondos')
      .upload(fileName, file, { upsert: true })

    if (uploadError) {
      console.error('Error subiendo imagen:', uploadError)
      alert('Error subiendo imagen.')
      return
    }

    const { data: urlData } = supabase.storage.from('fondos').getPublicUrl(fileName)
    const publicUrl = urlData.publicUrl

    // ✅ Actualizamos el estado visual
    setVisual(prev => ({ ...prev, fondo_url: publicUrl }))
  }
  const handleLogoUpload = async (e) => {
  const file = e.target.files[0]
  if (!file) return

  const slug = window.location.hostname.split('.')[0] === 'localhost' ? 'ejemplo' : window.location.hostname.split('.')[0]
  const fileName = `${slug}/${Date.now()}_${file.name}`

  const { data, error } = await supabase.storage.from('logos').upload(fileName, file)

  if (error) {
    console.error('Error subiendo logo:', error)
    alert('Error subiendo logo.')
    return
  }

  const { data: urlData } = supabase.storage.from('logos').getPublicUrl(fileName)
  const publicUrl = urlData.publicUrl

  setVisual(prev => ({ ...prev, logo_url: publicUrl }))
} 
function darkenColor(hex, percent) {
  const num = parseInt(hex.slice(1), 16)
  const amt = Math.round(2.55 * percent)
  const R = (num >> 16) - amt
  const G = ((num >> 8) & 0x00FF) - amt
  const B = (num & 0x0000FF) - amt

  return `#${(
    0x1000000 +
    (R < 255 ? (R < 0 ? 0 : R) : 255) * 0x10000 +
    (G < 255 ? (G < 0 ? 0 : G) : 255) * 0x100 +
    (B < 255 ? (B < 0 ? 0 : B) : 255)
  )
    .toString(16)
    .slice(1)}`
}



  return (
    <div className="admin-panel-box">
      
      <div className="admin-buttons">
      <button onClick={() => setMostrarEditorVisual(true)} className="edit">
        Editar Apariencia
      </button>
      <button onClick={() => setMostrarEditorRestaurante(true)} className="edit">
        Editar Restaurante
      </button>
      </div>
<h2>Agenda de Reservas</h2>
      {mostrarEditorVisual && (
  <div className="editor-modal">
  <div className="editor-box">
    <h3>Personalización Visual</h3>
    <form onSubmit={handleVisualSubmit}>
      <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
        
        {/* Colores */}
        <div className="form-group" style={{ flex: 1 }}>
          <label>Color Primario</label>
          <input
            type="color"
            value={visual.color_primario}
            onChange={(e) => updateVisual('color_primario', e.target.value)}
            style={{
              border: 'none',
              height: '40px',
              width: '100%',
              borderRadius: '8px',
              background: 'none',
              padding: 0,
              cursor: 'pointer'
            }}
          />
        </div>

        <div className="form-group" style={{ flex: 1 }}>
          <label>Color Secundario</label>
          <input
            type="color"
            value={visual.color_secundario}
            onChange={(e) => updateVisual('color_secundario', e.target.value)}
            style={{
              border: 'none',
              height: '40px',
              width: '100%',
              borderRadius: '8px',
              background: 'none',
              padding: 0,
              cursor: 'pointer'
            }}
          />
        </div>

        {/* Imágenes en horizontal */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', width: '100%' }}>
          <div className="form-group" style={{ flex: '1 1 45%' }}>
            <label>Imagen de fondo</label>
            <input type="file" accept="image/*" onChange={handleImageUpload} />
            {visual.fondo_url && (
              <img src={visual.fondo_url} alt="Vista previa fondo" style={{ width: '100%', marginTop: '0.5rem', borderRadius: '8px' }} />
            )}
          </div>

          <div className="form-group" style={{ flex: '1 1 45%' }}>
            <label>Logo</label>
            <input type="file" accept="image/*" onChange={handleLogoUpload} />
            {visual.logo_url && (
              <img src={visual.logo_url} alt="Vista previa logo" style={{ maxWidth: '120px', marginTop: '0.5rem', borderRadius: '8px' }} />
            )}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
        <button type="submit" className="secondary">Guardar</button>
        <button type="button" className="secondary" onClick={() => setMostrarEditorVisual(false)}>Cerrar</button>
      </div>
    </form>
  </div>
</div>

)}
      {mostrarEditorRestaurante && (
  <div className="editor-modal">
    <div className="editor-box">
      <h3>Gestión del Restaurante</h3>
      <form onSubmit={handleRestauranteSubmit}>
        <div className="form-group" style={{ flex: '1 1 100%' }}>
          <label>Nombre del restaurante</label>
          <input
            type="text"
            value={visual.nombre}
            onChange={(e) => updateVisual('nombre', e.target.value)}
          />
        </div>
        {/* Nombre */}
        
        <div className="form-group" style={{ flex: '1 1 100%' }}>
          <label>Dirección</label>
          <input
            type="text"
            value={visual.direccion}
            onChange={(e) => updateVisual('direccion', e.target.value)}
          />
        </div>
        <div className="form-group" style={{ flex: '1 1 100%' }}>
          <label>Turnos y Horarios</label>
          {visual.turnos?.map((turno, index) => (
            <div key={index} style={{ display: 'flex', gap: '8px', marginBottom: '5px' }}>
              <input
                type="text"
                placeholder="Turno (ej: Mañana)"
                value={turno.nombre}
                onChange={(e) => {
                  const updated = [...visual.turnos]
                  updated[index].nombre = e.target.value
                  setVisual(prev => ({ ...prev, turnos: updated }))
                }}
              />
              <input
                type="text"
                placeholder="Horas (ej: 12:00,12:30,13:00)"
                value={turno.horas}
                onChange={(e) => {
                  const updated = [...visual.turnos]
                  updated[index].horas = e.target.value
                  setVisual(prev => ({ ...prev, turnos: updated }))
                }}
              />
              <button type="button" onClick={() => {
                const updated = [...visual.turnos];
                updated.splice(index, 1);
                setVisual(prev => ({ ...prev, turnos: updated }));
              }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"  strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>

            </div>
          ))}
          <button type="button" onClick={() => setVisual(prev => ({
            ...prev, turnos: [...(prev.turnos || []), { nombre: '', horas: '' }]
          }))}>Añadir turno</button>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
          <button type="submit" className="secondary">Guardar</button>
          <button type="button" className="secondary" onClick={() => setMostrarEditorRestaurante(false)}>Cerrar</button>
        </div>
      </form>
    </div>
  </div>
)}
{reservaEditando && (
  <div className="editor-modal">
    <div className="editor-box">
      <h3>Editar Reserva</h3>
      <form onSubmit={handleGuardarReserva}>
  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

    

{mostrarDatePicker && (
  <DatePickerModal
    selectedDate={new Date(reservaEditando.date)}
    onSelectDate={(selectedDate) => {
      const year = selectedDate.getFullYear()
      const month = String(selectedDate.getMonth() + 1).padStart(2, '0')
      const day = String(selectedDate.getDate()).padStart(2, '0')
      const formattedDate = `${year}-${month}-${day}`
      setReservaEditando({ ...reservaEditando, date: formattedDate })
    }}
    onClose={() => setMostrarDatePicker(false)}
  />
)}


    <div className="form-group">
      <label>Nombre</label>
      <input
        type="text"
        value={reservaEditando.name}
        onChange={(e) => setReservaEditando({ ...reservaEditando, name: e.target.value })}
      />
    </div>

    <div className="form-group" style={{ display: 'flex', gap: '1rem' }}>
      <div style={{ flex: 1 }}>
        <label>Email</label>
        <input
          type="email"
          value={reservaEditando.email}
          onChange={(e) => setReservaEditando({ ...reservaEditando, email: e.target.value })}
        />
      </div>

      <div style={{ flex: 1 }}>
        <label>Teléfono</label>
        <input
          type="text"
          value={reservaEditando.phone}
          onChange={(e) => setReservaEditando({ ...reservaEditando, phone: e.target.value })}
        />
      </div>
    </div>

    <div className="form-group" style={{ display: 'flex', gap: '1rem' }}>
      <div style={{ flex: 1 }}>
        <label>Fecha</label>
        <input
          type="text"
          readOnly
          value={reservaEditando.date}
          onClick={() => setMostrarDatePicker(true)}
          style={{ cursor: 'pointer' }}
        />
      </div>
      <div style={{ flex: 1 }}>
        <label>Personas</label>
        <input
          type="text"
          value={reservaEditando.guests}
          onChange={(e) => setReservaEditando({ ...reservaEditando, guests: parseInt(e.target.value) || "" })}
        />
      </div>

      
    </div>

    {reservaEditando.turno && (
  <div className="form-group" style={{ display: 'flex', gap: '1rem' }}>
    <div style={{ flex: 1 }}>
      <label>Turno</label>
      <select
        value={reservaEditando.turno}
        onChange={(e) => {
          const nuevoTurno = e.target.value;
          setReservaEditando({
            ...reservaEditando,
            turno: nuevoTurno,
            time: ''
          });
        }}
      >
        {visual.turnos.map((turno, index) => (
          <option key={index} value={turno.nombre}>{turno.nombre}</option>
        ))}
      </select>
    </div>

    <div style={{ flex: 1 }}>
      <label>Hora</label>
      <select
        value={reservaEditando.time}
        onChange={(e) => setReservaEditando({ ...reservaEditando, time: e.target.value })}
      >
        {visual.turnos.find(t => t.nombre === reservaEditando.turno)?.horas
          .split(',')
          .map((hora, idx) => (
            <option key={idx} value={hora.trim()}>{hora.trim()}</option>
          ))}
      </select>
    </div>
  </div>
)}


    <div className="form-group">
      <label>Peticiones especiales</label>
      <textarea
        rows="3"
        value={reservaEditando.specialRequests}
        onChange={(e) => setReservaEditando({ ...reservaEditando, specialRequests: e.target.value })}
      />
    </div>

  </div>

  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
    <button type="submit" className="secondary">Guardar</button>
    <button type="button" className="secondary" onClick={() => setReservaEditando(null)}>Cerrar</button>
  </div>
</form>

    </div>
  </div>
)}




      <AgendaCalendar
        selectedDate={date}
        onSelectDate={setDate}
        diasConReservas={diasConReservas}
      />

      <h3 style={{ marginTop: '10px' }}>
        {date.toLocaleDateString('es-ES', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })}
      </h3>

      {loading ? (
        <p>Cargando reservas...</p>
      ) : reservas.length === 0 ? (
        <p>No hay reservas este día.</p>
      ) : (
        <ul className="reservas-list">
          {reservas.map((r) => (
            <li key={r.id} className="reserva-item">
              <div className="items-reserva" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
  <div>
    <strong>{r.name}</strong> - {r.time} ({r.guests} personas)<br/>
    Email: {r.email} | Tel: {r.phone}
              {r.specialRequests && <em><br />Nota: {r.specialRequests}</em>}
  </div>
  <button 
    className="edit-button" 
    onClick={() => handleEditarReserva(r)}
    style={{ marginTop: '5px' }}
  >
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 20h9" />
    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
  </svg>
  </button>
</div>
              
              
            </li>
            
          ))}
        </ul>
      )}
    </div>
    
  )
}

export default AdminPanel
