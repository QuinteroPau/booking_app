import { useState, useRef, useEffect } from 'react'
import { useFormik } from 'formik'
import * as Yup from 'yup'
import TimeSlotPicker from './TimeSlotPicker'
import '../styles/main.css'
import AgendaCalendar from './AgendaCalendar'
import supabase from '../supabaseClient'

const ReservationForm = ({ step, setStep }) => {
  const [submitted, setSubmitted] = useState(false)
  const [availableTimes, setAvailableTimes] = useState([])
  const [showCalendar, setShowCalendar] = useState(false)
  const calendarRef = useRef(null)
  const [tempDate, setTempDate] = useState(new Date())
  const [turnosDisponibles, setTurnosDisponibles] = useState([])
  const formatDate = (date) => {
  return date.toLocaleDateString('sv-SE')  // Formato YYYY-MM-DD
}
  // ✅ Cargamos los turnos desde Supabase
  useEffect(() => {
    const fetchTurnos = async () => {
      let slug = 'ejemplo'  // o la lógica de slug de tu multisitio
      const { data, error } = await supabase
        .from('restaurantes')
        .select('turnos')
        .eq('slug', slug)
        .single()

      if (error) {
        console.error('Error al obtener turnos:', error)
      } else {
        setTurnosDisponibles(data.turnos || [])
      }
    }

    fetchTurnos()
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target)) {
        setShowCalendar(false)
      }
    }
    if (showCalendar) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [showCalendar])

  const formik = useFormik({
    initialValues: {
      date: '',
      time: '',
      shift: '',
      guests: 2,
      name: '',
      email: '',
      phone: '',
      specialRequests: ''
    },
    validationSchema: Yup.object({
      date: Yup.date().required('Requerido'),
      time: Yup.string().required('Requerido'),
      shift: Yup.string().required('Selecciona un turno'),
      guests: Yup.number().min(1).max(12).required('Requerido'),
      name: Yup.string().required('Requerido'),
      email: Yup.string().email('Email inválido').required('Requerido').matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Email inválido'),
      phone: Yup.string().required('Requerido').matches(/^\+?[0-9\s\-]{9,20}$/, 'Teléfono inválido')
    }),
    onSubmit: async (values) => {
      try {
        const { error } = await supabase.from('reservas').insert([{
          date: values.date,
          time: values.time,
          guests: values.guests,
          name: values.name,
          email: values.email,
          phone: values.phone,
          turno: values.shift,
          special_requests: values.specialRequests
        }])
        if (error) {
          console.error('Error al insertar en Supabase:', error)
        } else {
          setSubmitted(true)
        }
      } catch (error) {
        console.error('Error de red o conexión:', error)
      }
    }
  })

  if (submitted) {
    return (
      <div className="confirmation">
        <h2>¡Reserva Confirmada!</h2>
        <p>Hemos enviado los detalles a tu correo electrónico.</p>
      </div>
    )
  }

  const disableStep1Next = !formik.values.shift || formik.values.guests > 12
  const disableStep2Next = !formik.values.time
  const disableStep3Next = !formik.values.email.trim() || !formik.values.phone.trim() || !formik.values.name.trim()

  return (
    <form onSubmit={formik.handleSubmit} className="reservation-form">
      
      {step === 1 && (
        <>
          <div className="form-group">
            <h3 className="step-title">Fecha</h3>
            <AgendaCalendar selectedDate={tempDate} onSelectDate={setTempDate} diasConReservas={[]} />
          </div>

          <div className="form-group">
            <h3 className="step-title">Personas</h3>
            <div className="people-counter">
              <button type="button" onClick={() => formik.setFieldValue('guests', Math.max(1, formik.values.guests - 1))}>−</button>
              <input
                type="number"
                value={formik.values.guests}
                onChange={(e) => {
                  const value = e.target.value
                  if (value === '') {
                    formik.setFieldValue('guests', '')
                    formik.setFieldError('guests', '')
                  } else {
                    const num = parseInt(value)
                    if (!isNaN(num)) {
                      formik.setFieldValue('guests', num)
                      if (num > 12) {
                        formik.setFieldError('guests', 'Para más de 12 personas, por favor llama al restaurante')
                      } else {
                        formik.setFieldError('guests', '')
                      }
                    }
                  }
                }}
                onBlur={() => {
                  const num = parseInt(formik.values.guests)
                  if (isNaN(num) || num < 1) {
                    formik.setFieldValue('guests', 1)
                    formik.setFieldError('guests', '')
                  }
                }}
              />
              <button type="button" onClick={() => formik.setFieldValue('guests', Math.min(20, formik.values.guests + 1))}>+</button>
            </div>
          </div>

          {formik.errors.guests && <div className="error-message">{formik.errors.guests}</div>}

          <div className="form-group">
            <h3 className="step-title">Turno</h3>
            <div className="shift-selector" role="group">
              {turnosDisponibles.map((turno, index) => (
                <button
                  key={index}
                  type="button"
                  className={`shift-option ${formik.values.shift === turno.nombre ? 'selected' : ''}`}
                  onClick={() => {
                    formik.setFieldValue('shift', turno.nombre)
                    const horasArray = turno.horas.split(',').map(hora => hora.trim())
                    setAvailableTimes(horasArray)
                  }}
                >
                  {turno.nombre}
                </button>
              ))}
            </div>
            {formik.touched.shift && formik.errors.shift && (
              <div className="error">{formik.errors.shift}</div>
            )}
          </div>

          <div className="button-group">
            <button
              type="button"
              disabled={disableStep1Next}
              className={`next-button ${disableStep1Next ? 'disabled' : ''}`}
              onClick={() => {
                formik.setFieldValue('date', formatDate(tempDate))
                setStep(2)
              }}
            >
              Siguiente
            </button>
          </div>
        </>
      )}

      {step === 2 && (
        <>
          <div className="form-group">
            <h3 className="step-title">Hora</h3>
            <TimeSlotPicker availableTimes={availableTimes} selectedTime={formik.values.time} onSelect={(time) => formik.setFieldValue('time', time)} />
            {formik.touched.time && formik.errors.time && <div className="error">{formik.errors.time}</div>}
          </div>

          <div className="button-group">
            <button type="button" className="back-button" onClick={() => setStep(1)}>Atrás</button>
            <button type="button" disabled={disableStep2Next} className={`next-button ${disableStep2Next ? 'disabled' : ''}`} onClick={() => setStep(3)}>Siguiente</button>
          </div>
        </>
      )}

      {step === 3 && (
        <>
          <div className="form-group">
            <div className="reservation-summary">
  <h3 className="summary-title">Confirma los detalles de tu reserva</h3>
  <div className="summary-items">
    <div className="summary-item">
      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none"
        stroke="var(--primary-color)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
        <line x1="16" y1="2" x2="16" y2="6" />
        <line x1="8" y1="2" x2="8" y2="6" />
        <line x1="3" y1="10" x2="21" y2="10" />
      </svg>
      <h4>{formik.values.date}</h4>
    </div>
    <div className="summary-item">
      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none"
        stroke="var(--primary-color)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20 21v-2a4 4 0 0 0-3-3.87M4 21v-2a4 4 0 0 1 3-3.87" />
        <circle cx="12" cy="7" r="4" />
      </svg>
      <h4> {formik.values.guests}</h4>
    </div>
    <div className="summary-item">
      <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none"
        stroke="var(--primary-color)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <path d="M12 6v6l4 2" />
      </svg>
      <h4>{formik.values.time}</h4>
    </div>
    <button
      type="button"
      className="modify-button"
      onClick={() => {
        setStep(1)
        formik.setFieldValue('time', '') // ❗ borrar la hora seleccionada
      }}
    >
      Modificar
    </button>

  </div> </div>
          </div>

          <div className="form-group">
            <label>Nombre</label>
            <input id="name" name="name" type="text" onChange={formik.handleChange} value={formik.values.name} />
            {formik.touched.name && formik.errors.name && <div className="error">{formik.errors.name}</div>}
            <label>Email</label>
            <input id="email" name="email" type="email" onChange={formik.handleChange} value={formik.values.email} />
            {formik.touched.email && formik.errors.email && <div className="error">{formik.errors.email}</div>}
          </div>

          <div className="form-group">
            
          </div>

          <div className="form-group">
            <label>Teléfono</label>
            <input id="phone" name="phone" type="tel" onChange={formik.handleChange} value={formik.values.phone} />
            {formik.touched.phone && formik.errors.phone && <div className="error">{formik.errors.phone}</div>}
          </div>

          <div className="form-group">
            <label>Peticiones especiales</label>
            <textarea id="specialRequests" name="specialRequests" rows="3" onChange={formik.handleChange} value={formik.values.specialRequests} />
          </div>

          <div className="button-group">
            <button type="submit" className={`next-button ${disableStep3Next ? 'disabled' : ''}`} disabled={disableStep3Next}>
              Confirmar Reserva
            </button>
          </div>
        </>
      )}
    </form>
  )
}

export default ReservationForm
